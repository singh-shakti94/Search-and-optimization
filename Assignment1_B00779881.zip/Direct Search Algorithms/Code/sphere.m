function [out] = sphere(x)
out = x.'*x;
end
